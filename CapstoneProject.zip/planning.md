PAGE 1      Profile Page

    Nav-bar
    Font: Ubuntu, strong, large
    Font color: #A64F3C
    Highlighted color: #467302;
        Home    Photos    contact     media


    H1 Header   Mark Derudder violinist
    Font: Ubuntu, strong, largest
    Font color: #593F27;

        Image: photo of myself

    H2 Header
    Font: Ubuntu, strong, large
        text-section    chamber music
    H2 Header
        text-section    solo
    H2 Header
        text-section    orchestra


PAGE 2      Contact Form

    Nav-bar
        Photos    Contact     media

    HTML contact form
        1 fieldset
            <legend> add friend
        3 inputs
            3 text
                <firstname>
                <surname>
                <email>
            1 checkbox
                <sign up to newsletter>
        1 textarea
            <message>
        Appropriate labels for the above
        1 button
            <submit button>

PAGE 3      Media and Collaborations

    Nav-bar 
        Photos    Contact     media
    
    H1 Header
        Media 

    H2 Header
        Collaborations
            list with colaborator websites:
                Alex koo
                    img
                Daniel Deruds
                    img
                Pau cod
                    img
                Futeau
                    img
                BSO
                    img

PAGE 4

    Nav bar
        Photos    Contact     media

    H1 Header
        <photos>
    
        6 x <img> 
    3fr width x 2fr height
    <label>
    img is also link opening the img in new window
    